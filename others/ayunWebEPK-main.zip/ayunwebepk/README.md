# ayunWebEPK
Compile EPK files in your browser!

Utilizes:
- [JSZip](https://github.com/Stuk/jszip)
- [pako](https://github.com/nodeca/pako)
- [js-sha1](https://github.com/emn178/js-sha1)
- [Nunito Font](https://fonts.google.com/specimen/Nunito)