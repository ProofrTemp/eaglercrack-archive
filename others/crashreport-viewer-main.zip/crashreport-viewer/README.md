## Crash Report Viewer

Configurable web application, reads a "crash report" and deobfuscates minified javascript stack traces within it using a source map, also supports loading local source maps

### [https://deev.is/tools/crash-viewer/eagler-1.5.2/](https://deev.is/tools/crash-viewer/eagler-1.5.2/)

Screenshot:

![https://i.gyazo.com/58fd52e75b4c0361122ca930eb180c4a.png](https://i.gyazo.com/58fd52e75b4c0361122ca930eb180c4a.png)
